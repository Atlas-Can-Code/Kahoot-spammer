
# Spencer Hon
Please dont copy code and not give gredit to the OG creator

Kahoot Bot is a program especially designed to make people confused.
Great for April fools pranks and jokes.

Running